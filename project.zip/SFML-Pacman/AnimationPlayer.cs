﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SFMLPacman
{
    public class AnimationPlayer
    {
        private Dictionary<string, Dictionary<byte, List<int[]>>> animation = new Dictionary<string, Dictionary<byte, List<int[]>>>();
        private Dictionary<string, float> animation_frame_dur = new Dictionary<string, float>();
        private float acc_time = 0.0f;
        private int cur_frame = 0;
        private Entity anim_target;

        public int Frame
        {
            get {
                return cur_frame;
            }
        }

        public AnimationPlayer(Entity t) {
            anim_target = t;
        }

        public void ResetFrames() {
            cur_frame = 0;
            acc_time = 0.0f;
        }

        public int GetAnimationFrameCount(string aname, byte dir) {
            return animation[aname][dir].Count;
        }

        public void LoadAnimaton(string p) {
            using (StreamReader _FIload = File.OpenText(p))
            {
                string rd_line;
                string scope = "";

                while ((rd_line = _FIload.ReadLine()) != null) {
                    string[] lineargs = rd_line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    if (lineargs.Length >= 2)
                    {
                        if (lineargs[0][0] == '\"' && lineargs.Length == 2)
                        {
                            animation.Add(lineargs[0].Replace("\"", ""), new Dictionary<byte, List<int[]>>());
                            animation_frame_dur.Add(lineargs[0].Replace("\"", ""), Convert.ToSingle(lineargs[1]));
                            scope = lineargs[0].Replace("\"", "");
                        }

                        if (lineargs[0].Contains("td") && lineargs.Length == 9 && scope != "")
                        {
                            int[] txcoords = new int[8];
                            for (int i = 1; i < lineargs.Length; i++)
                            {
                                txcoords[i - 1] = Convert.ToInt32(lineargs[i]);
                            }
                            if (!animation[scope].ContainsKey((byte)(lineargs[0][2] - '0')))
                            {
                                animation[scope].Add((byte)(lineargs[0][2] - '0'), new List<int[]>());
                            }
                            animation[scope][(byte)(lineargs[0][2] - '0')].Add(txcoords);
                        }
                    }
                }
            }
        }

        public void PlayAnimation(string aname, float dt){
            if(animation.ContainsKey(aname) && (animation[aname].ContainsKey(anim_target.GetDirection()) || animation[aname].ContainsKey(4))) {
                acc_time += dt;
                acc_time = acc_time > 0.0f ? acc_time : 0.0f;
                if (acc_time >= animation_frame_dur[aname]) {
                    cur_frame++;

                    byte dir = (animation[aname].ContainsKey(4) && !animation[aname].ContainsKey(anim_target.GetDirection())) ? (byte)4 : anim_target.GetDirection();
                    if (cur_frame >= animation[aname][dir].Count) {
                        cur_frame = 0;
                    }
                    acc_time -= animation_frame_dur[aname];
                    anim_target.SetTextureCoords(animation[aname][dir][cur_frame]);
                }
            }
        }
    }
}
