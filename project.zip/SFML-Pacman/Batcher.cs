﻿using System.Linq;
using System.Collections.Generic;
using SFML.Graphics;
using SFML.System;
using System;

namespace SFMLPacman
{
    class Batcher : Drawable
    {
        private List<Vertex> vertices = new List<Vertex>();
        private List<Vertex> imgtext_vrtx_buffer = new List<Vertex>();
        private Texture texture;
        private List<Entity> entities = new List<Entity>();
        private List<ImgText> imgtexts = new List<ImgText>();
        private List<int> entity_vertices_offset_ids = new List<int>();
        private Map map;
        private int map_vertices_offset;

        public Batcher(string p) {
            texture = new Texture(p);
        }

        private void AddImgText() {
            vertices.RemoveRange(vertices.Count-imgtext_vrtx_buffer.Count, imgtext_vrtx_buffer.Count);
            imgtext_vrtx_buffer.Clear();
            for (int i = 0; i < imgtexts.Count; i++) {
                for(int j = 0; j < imgtexts[i].GetVertices().Count; j++)
                {
                    Vertex v = imgtexts[i].GetVertices()[j];
                    v.Position += imgtexts[i].Position;
                    v.Position.X *= imgtexts[i].Scale.X;
                    v.Position.Y *= imgtexts[i].Scale.Y;
                    imgtext_vrtx_buffer.Add(v);
                }
            }
            vertices.AddRange(imgtext_vrtx_buffer);
        }

        private void UpdateMap() { 
            for(int i = map_vertices_offset; i < map_vertices_offset+map.GetVertices().Count; i++) {
                vertices[i] = map.GetVertices()[i-map_vertices_offset];
            }
        }

        private void UpdateEntities() {
            for (int i = 0; i < entity_vertices_offset_ids.Count; i++) {
                int k = 0;
                int end = (entities[i] is Ghost) ? 8 : 4;
                for (int j = entity_vertices_offset_ids[i]; j < entity_vertices_offset_ids[i] + end; j++) {
                    vertices[j] = entities[i].GetVertices()[k];
                    k++;
                }
            }
            for (int i = 0; i < entity_vertices_offset_ids.Count; i++){
                vertices[entity_vertices_offset_ids[i]] = new Vertex(entities[i].Position, entities[i].GetVertices()[0].Color, entities[i].GetVertices()[0].TexCoords);
                vertices[entity_vertices_offset_ids[i] + 1] = new Vertex(new Vector2f(entities[i].Position.X + entities[i].EntitySize.X * entities[i].Scale.X, entities[i].Position.Y), entities[i].GetVertices()[1].Color, entities[i].GetVertices()[1].TexCoords);
                vertices[entity_vertices_offset_ids[i] + 2] = new Vertex(new Vector2f(entities[i].Position.X + entities[i].EntitySize.X * entities[i].Scale.X, entities[i].Position.Y + entities[i].EntitySize.Y * entities[i].Scale.Y), entities[i].GetVertices()[2].Color, entities[i].GetVertices()[2].TexCoords);
                vertices[entity_vertices_offset_ids[i] + 3] = new Vertex(new Vector2f(entities[i].Position.X, entities[i].Position.Y + entities[i].EntitySize.Y * entities[i].Scale.Y), entities[i].GetVertices()[3].Color, entities[i].GetVertices()[3].TexCoords);
                if(entities[i] is Ghost) {
                    vertices[entity_vertices_offset_ids[i] + 4] = new Vertex(entities[i].Position, entities[i].GetVertices()[4].Color, entities[i].GetVertices()[4].TexCoords);
                    vertices[entity_vertices_offset_ids[i] + 5] = new Vertex(new Vector2f(entities[i].Position.X + entities[i].EntitySize.X * entities[i].Scale.X, entities[i].Position.Y), entities[i].GetVertices()[5].Color, entities[i].GetVertices()[5].TexCoords);
                    vertices[entity_vertices_offset_ids[i] + 6] = new Vertex(new Vector2f(entities[i].Position.X + entities[i].EntitySize.X * entities[i].Scale.X, entities[i].Position.Y + entities[i].EntitySize.Y * entities[i].Scale.Y), entities[i].GetVertices()[6].Color, entities[i].GetVertices()[6].TexCoords);
                    vertices[entity_vertices_offset_ids[i] + 7] = new Vertex(new Vector2f(entities[i].Position.X, entities[i].Position.Y + entities[i].EntitySize.Y * entities[i].Scale.Y), entities[i].GetVertices()[7].Color, entities[i].GetVertices()[7].TexCoords);
                }
            }
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            if (map != null) {
                UpdateMap();
            }
            UpdateEntities();
            if (imgtexts.Count >= 1) {
                AddImgText();
            }
            states.Texture = texture;
            target.Draw(vertices.ToArray(), PrimitiveType.Quads, states);
        }

        private void AddVertices(List<Vertex> vl, bool is_entity) {
            vertices.AddRange(vl);
            if (is_entity) {
                if (entities[entities.Count - 1] is Ghost)
                {
                    entity_vertices_offset_ids.Add(vertices.Count - 8);
                }
                else {
                    entity_vertices_offset_ids.Add(vertices.Count - 4);
                }
            }
            else{
                map_vertices_offset = vertices.Count - vl.Count;
            }
        }

        public void Add(Entity e){
            entities.Add(e);
            AddVertices(e.GetVertices(), true);
        }

        public void Add(Map m)
        {
            map = m;
            AddVertices(m.GetVertices(), false);
        }

        public void Add(ImgText imgtext) {
            imgtexts.Add(imgtext);
        }

        public void Clear() {
            entities.Clear();
            entity_vertices_offset_ids.Clear();
            imgtexts.Clear();
            imgtext_vrtx_buffer.Clear();
            vertices.Clear();
        }
    }
}
