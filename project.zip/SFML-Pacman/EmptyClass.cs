﻿using System;
using NUnit.Framework;

namespace SFMLPacman
{
    [TestFixture]
    public class Test
    {
        public void test(){
            
        }
    }
}
