﻿using System;
using System.Collections.Generic;
using System.IO;
using SFML.Graphics;
using SFML.System;

namespace SFMLPacman
{
    public abstract class Entity : Transformable, Drawable
    {
        protected List<Vertex> vertices = new List<Vertex>();
        protected Texture texture;
        protected byte dir;
        protected Vector2f entity_size;
        protected FloatRect collision_rect;
        protected Color entity_color;
        protected int shrink_end = 0;

        public Vector2f EntitySize
        {
            get {
                return entity_size;
            }
        }

        public Entity(Vector2f size, Color c, int [] txc) {
            entity_size = size;
            vertices.Add(new Vertex(new Vector2f(0, 0), c, new Vector2f(txc[0], txc[1])));
            vertices.Add(new Vertex(new Vector2f(size.X, 0), c, new Vector2f(txc[2], txc[3])));
            vertices.Add(new Vertex(new Vector2f(size.X, size.Y), c, new Vector2f(txc[4], txc[5])));
            vertices.Add(new Vertex(new Vector2f(0, size.Y), c, new Vector2f(txc[6], txc[7])));
            entity_color = c;
        }

        public byte GetDirection()
        {
            return dir;
        }


        public void SetTexture(string txpath) {
            texture = new Texture(txpath);
        }

        public void SetTextureCoords(int [] txc) {
            for(int i = 0; i < vertices.Count-shrink_end; i++) {
                Vertex v = vertices[i];
                v.TexCoords = new Vector2f(txc[i*2], txc[i*2+1]);
                vertices[i] = v;
            }
        }

        public bool Collides(Map m) {
            FloatRect entity_rect = new FloatRect(Position, new Vector2f(vertices[1].Position.X - vertices[0].Position.X, vertices[3].Position.Y - vertices[0].Position.Y));
            for (int i = 0; i < m.GetWallsVertices().Count; i += 4) {
                FloatRect tile_rect = new FloatRect(new Vector2f(m.GetWallsVertices()[i].Position.X+4, m.GetWallsVertices()[i].Position.Y + 4), new Vector2f((m.GetWallsVertices()[i+1].Position.X - m.GetWallsVertices()[i].Position.X)/2, (m.GetWallsVertices()[i+3].Position.Y - m.GetWallsVertices()[i].Position.Y)/2));

                if (entity_rect.Intersects(tile_rect)) {
                    return true;
                }
            }
            return false;
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            states.Transform *= Transform;
            states.Texture = texture;
            target.Draw(vertices.ToArray(), PrimitiveType.Quads, states);
        }

        protected void InternalSetColor(Color c) { 
            for(int i = 0; i < vertices.Count - shrink_end; i++) {
                Vertex v = vertices[i];
                v.Color = c;
                vertices[i] = v;
            }
        }

        public List<Vertex> GetVertices(){
            return vertices;
        }
    }

    public class Pacman : Entity
    {
        private float default_speed = 7128.0f;
        private float speed;
        private sbyte lifes = 2;
        private uint score = 0;
        private bool isdying = false;

        private float energizer_timer = 0.0f;

        private uint eaten_ghost_count = 0;
        private int bonus_life = 2;

        public float EnergizerTimer {
            get {
                return energizer_timer;
            }
        }

        public uint Score {
            get {
                return score;
            }
        }
        public int Lifes
        {
            get
            {
                return lifes;
            }
        }
        public bool IsDying
        {
            get {
                return isdying;
            }
        }

        private AnimationPlayer animation;
        private SoundPlayer soundPlayer;

        public Pacman(Vector2f size, Color c, int[] txc, string volstr) : base(size, c, txc)
        {
            dir = 0;
            animation = new AnimationPlayer(this);
            soundPlayer = new SoundPlayer();
            soundPlayer.SetVolume(Convert.ToSingle(volstr));
            animation.LoadAnimaton("assets/configs/animations/pacman.animation".Replace('/', Path.DirectorySeparatorChar));
            soundPlayer.LoadSounds("assets/configs/sounds/pacman_sounds.txt".Replace('/', Path.DirectorySeparatorChar));
        }

        public void SetDirection(byte d)
        {
            dir = d;
        }

        public void ResetEnergizer() {
            energizer_timer = 0.0f;
        }

        public void Restart() {
            dir = 0;
            lifes = 2;
            bonus_life = 2;
            score = 0;
            isdying = false;
            animation.PlayAnimation("idle", 0.0001f);
        }

        private int Eats(Map m) {
            FloatRect entity_rect = new FloatRect(Position, new Vector2f(vertices[1].Position.X - vertices[0].Position.X, vertices[3].Position.Y - vertices[0].Position.Y));
            for (int i = 0; i < m.GetEdiblesVertices().Count; i += 4)
            {
                FloatRect tile_rect = new FloatRect(new Vector2f(m.GetEdiblesVertices()[i].Position.X + ((m.GetEdiblesVertices()[i + 1].Position.X - m.GetEdiblesVertices()[i].Position.X) / 2), m.GetEdiblesVertices()[i].Position.Y + ((m.GetEdiblesVertices()[i + 3].Position.Y - m.GetEdiblesVertices()[i].Position.Y) / 2)), new Vector2f((m.GetEdiblesVertices()[i + 1].Position.X - m.GetEdiblesVertices()[i].Position.X)/4-3, (m.GetEdiblesVertices()[i + 3].Position.Y - m.GetEdiblesVertices()[i].Position.Y)/4-3));

                if (entity_rect.Intersects(tile_rect) && m.GetEdiblesVertices()[i].Color.A != 0)
                {
                    return i;
                }
            }
            return -1;
        }

        public void EatsGhost() {
            eaten_ghost_count++;
            score += eaten_ghost_count * 200;
            BonusLife();
            soundPlayer.PlaySound("eat_ghost");
        }

        public bool Die(float dtime) {
            energizer_timer = 0.0f;
            if (!isdying)
            {
                animation.ResetFrames();
                isdying = true;
                lifes--;
                soundPlayer.PlaySound("death");
            }
            if (animation.Frame < animation.GetAnimationFrameCount("death", 4)-1)
            {
                animation.PlayAnimation("death", dtime * 10);
            }
            else {
                isdying = false;
                animation.ResetFrames();
                return true;
            }

            return false;
        }

        private void BonusLife(){
            if(score >= bonus_life * 5000 && score >= 10000 && lifes < 4) {
                lifes++;
                bonus_life++;
            }
        }

        public void EnergizerClock(float dtime) {
            if (energizer_timer > 0.0f)
            {
                energizer_timer -= dtime * 10;
                energizer_timer = (energizer_timer <= 0.0f) ? 0.0f : energizer_timer;
                eaten_ghost_count = (energizer_timer <= 0.0f) ? 0 : eaten_ghost_count;
            }
            return;
        }

        public void Move(float dtime, Map m, uint level) {
            float speed_factor = level / 386;
            speed_factor = speed_factor > 2.56f ? 2.56f : speed_factor;
            speed = default_speed + (default_speed * speed_factor);
            switch (dir) {
                case 0:
                    Position = new Vector2f(Position.X + dtime * speed, Position.Y);
                    animation.PlayAnimation("move", dtime * 10);
                    break;
                case 1:
                    Position = new Vector2f(Position.X, Position.Y - dtime * speed);
                    animation.PlayAnimation("move", dtime * 10);
                    break;
                case 2:
                    Position = new Vector2f(Position.X - dtime * speed, Position.Y);
                    animation.PlayAnimation("move", dtime * 10);
                    break;
                case 3:
                    Position = new Vector2f(Position.X, Position.Y + dtime * speed);
                    animation.PlayAnimation("move", dtime * 10);
                    break;
            }
            if (Position.X >= m.Size.X - 16)
            {
                Position = new Vector2f(Position.X - m.Size.X + 16, Position.Y);
            }
            if (Position.X <= 0)
            {
                Position = new Vector2f(Position.X + m.Size.X - 16, Position.Y);
            }
            if (Position.Y <= 0)
            {
                Position = new Vector2f(Position.X, Position.Y + m.Size.Y - 16);
            }
            if (Position.Y >= m.Size.Y - 16)
            {
                Position = new Vector2f(Position.X, Position.Y - m.Size.Y + 16);
            }
            if (this.Collides(m)) {
                this.Move(-dtime, m, level);
            }
            if (this.Eats(m) != -1) {
                uint score_amount = m.EdibleEaten(this.Eats(m), level);
                score += score_amount;

                if (score_amount == 10)
                {
                    soundPlayer.PlaySound("eat");
                }
                if (score_amount == 50) {
                    energizer_timer = 1.0f - (1.0f * (level/128));
                    soundPlayer.PlaySound("energizer");
                }
                if (score_amount >= 100) {
                    soundPlayer.PlaySound("eat_fruit");
                }
                BonusLife();
            }
        }
    }

    public class Ghost : Entity {
        private float default_speed = 6096.0f;
        private float speed;
        private string name;
        public string Name
        {
            get {
                return name;
            }
        }
        // mode_behavior відповідає за поведінку привида
        // 0 - привид пересувається до цільового тайла/переслідує Пакмена
        // 1 - привид наляканий
        // 2 - привид втікає додому
        private byte mode_behavior;
        private bool mode_movement;
        private Vector2f target_tile;
        private AnimationPlayer animation;
        private SoundPlayer soundPlayer;
        private float flashing_timer = 0.0f;
        private List<int[]> eyes_tx = new List<int[]>();

        private bool immune_to_energizer = false;
        private bool needs_to_go_out = false;

        public Ghost(Vector2f size, Color color, int[] txc, string ghost_name, string eyes_txpath, string volstr) : base(size, color, txc)
        {
            name = ghost_name;
            dir = 0;
            mode_behavior = 0;
            mode_movement = true;
            animation = new AnimationPlayer(this);
            soundPlayer = new SoundPlayer();
            soundPlayer.SetVolume(Convert.ToSingle(volstr));
            LoadEyesTx(eyes_txpath);
            vertices.Add(new Vertex(new Vector2f(0, 0), new Color(255, 255, 255, 255), new Vector2f(eyes_tx[0][0], eyes_tx[0][1])));
            vertices.Add(new Vertex(new Vector2f(size.X, 0), new Color(255, 255, 255, 255), new Vector2f(eyes_tx[0][2], eyes_tx[0][3])));
            vertices.Add(new Vertex(new Vector2f(size.X, size.Y), new Color(255, 255, 255, 255), new Vector2f(eyes_tx[0][4], eyes_tx[0][5])));
            vertices.Add(new Vertex(new Vector2f(0, size.Y), new Color(255, 255, 255, 255), new Vector2f(eyes_tx[0][6], eyes_tx[0][7])));
            animation.LoadAnimaton("assets/configs/animations/ghost.animation".Replace('/', Path.DirectorySeparatorChar));
            soundPlayer.LoadSounds("assets/configs/sounds/ghosts_sounds.txt".Replace('/', Path.DirectorySeparatorChar));
            shrink_end = 4;
        }

        private void LoadEyesTx(string path) {
            using (StreamReader _FIload = File.OpenText(path))
            {
                string rd_line;

                while ((rd_line = _FIload.ReadLine()) != null)
                {
                    string[] lineargs = rd_line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    if (lineargs.Length == 8) {
                        int[] txcoords = new int[8];
                        for (int i = 0; i < lineargs.Length; i++) {
                            txcoords[i] = Convert.ToInt32(lineargs[i]);
                        }
                        eyes_tx.Add(txcoords);
                    }
                }
            }
        }

        protected bool WillCollide(Map m, byte d, float dtime)
        {
            Vector2f temp_pos = new Vector2f(Position.X, Position.Y);

            temp_pos = new Vector2f((float)Math.Round(temp_pos.X), (float)Math.Round(temp_pos.Y));
            switch (d)
            {
                case 0:
                    temp_pos.X += dtime * speed;
                    break;
                case 1:
                    temp_pos.Y -= dtime * speed;
                    break;
                case 2:
                    temp_pos.X -= dtime * speed;
                    break;
                case 3:
                    temp_pos.Y += dtime * speed;
                    break;
            }
            temp_pos = new Vector2f((float)Math.Round(temp_pos.X), (float)Math.Round(temp_pos.Y));

            FloatRect entity_rect = new FloatRect(temp_pos, new Vector2f(vertices[1].Position.X - vertices[0].Position.X, vertices[3].Position.Y - vertices[0].Position.Y));
            for (int i = 0; i < m.GetWallsVertices().Count; i += 4)
            {
                FloatRect tile_rect = m.GetWallsVertices()[i].Color == new Color(159, 133, 115, 255) ? new FloatRect(new Vector2f(m.GetWallsVertices()[i].Position.X + 4, m.GetWallsVertices()[i].Position.Y), new Vector2f((m.GetWallsVertices()[i + 1].Position.X - m.GetWallsVertices()[i].Position.X) - 8, m.GetWallsVertices()[i + 3].Position.Y - m.GetWallsVertices()[i].Position.Y)) :
                new FloatRect(new Vector2f(m.GetWallsVertices()[i].Position.X, m.GetWallsVertices()[i].Position.Y), new Vector2f(m.GetWallsVertices()[i + 1].Position.X - m.GetWallsVertices()[i].Position.X, m.GetWallsVertices()[i + 3].Position.Y - m.GetWallsVertices()[i].Position.Y));

                if (entity_rect.Intersects(tile_rect))
                {
                    if (m.GetWallsVertices()[i].Color == new Color(159, 133, 115, 255) && needs_to_go_out)
                    {
                        return false;
                    }
                    return true;
                }
            }

            return false;
        }

        public void SwitchMode() {
            mode_movement = !mode_movement;
        }

        public void Reset() {
            mode_behavior = 0;
            InternalSetColor(entity_color);
        }

        public void ResetMode() {
            mode_movement = true;
        }

        private void UpdateTargets(Pacman p, Map m, Ghost blinky){
            string temp_name = name.ToLower();

            if (Equals(target_tile, new Vector2f(m.GetGhostHomeArea().Left + (m.GetGhostHomeArea().Width / 2), m.GetGhostHomeArea().Top + (m.GetGhostHomeArea().Height / 2)))
                && !m.GetGhostHomeArea().Contains(Position.X, Position.Y)){
                needs_to_go_out = true;
                return;
            }
            if (!m.GetGhostHomeArea().Contains(vertices[3].Position.X + Position.X, vertices[3].Position.Y + Position.Y) && needs_to_go_out)
            {
                if(Equals(new Vector2f((float)Math.Round(Position.X), (float)Math.Round(Position.Y)), target_tile)) {
                   needs_to_go_out = false;
                }
            }
            if (m.GetGhostHomeArea().Contains(Position.X, Position.Y)){
                needs_to_go_out = true;
            }

            if (needs_to_go_out)
            {
                if (mode_behavior == 2) {
                    mode_behavior = 0;
                    SwitchAlpha(false);
                }

                List<Vector2f> possible_exits = new List<Vector2f>();
                for(int i = 0; i < m.GetDoorsPos().Count; i++) {
                    Vector2f[] p_exit = { 
                        new Vector2f(m.GetDoorsPos()[i].X+16, m.GetDoorsPos()[i].Y),
                        new Vector2f(m.GetDoorsPos()[i].X-16, m.GetDoorsPos()[i].Y),
                        new Vector2f(m.GetDoorsPos()[i].X, m.GetDoorsPos()[i].Y+16),
                        new Vector2f(m.GetDoorsPos()[i].X, m.GetDoorsPos()[i].Y-16)
                    };
                    for (int j = 0; j < 4; j++)
                    {
                        bool found_wall = false;
                        for(int v = 0; v < m.GetWallsVertices().Count; v += 4) {
                            if (m.GetWallsVertices()[v].Position == p_exit[j] || m.GetGhostHomeArea().Contains(p_exit[j].X, p_exit[j].Y))
                            {
                                found_wall = true;
                            }
                        }
                        if (!found_wall) {
                            possible_exits.Add(p_exit[j]);
                        }
                    }
                }

                int rand_exit = new Random().Next(0, possible_exits.Count);
                target_tile = possible_exits[rand_exit];
                immune_to_energizer = true;
                return;
            }

            if (mode_movement)
            {
                switch (temp_name) {
                    case "blinky":
                        target_tile = new Vector2f(m.Size.X, -16);
                        break;
                    case "pinky":
                        target_tile = new Vector2f(0, -16);
                        break;
                    case "inky":
                        target_tile = new Vector2f(m.Size.X - 16, m.Size.Y + 16);
                        break;
                    case "clyde":
                        target_tile = new Vector2f(0, m.Size.Y + 16);
                        break;
                }
            }
            else {
                for (int i = 0; i < m.Size.X / 16; i++)
                {
                    for (int j = 0; j < m.Size.Y / 16; j++)
                    {
                        FloatRect pacman_tile = new FloatRect(new Vector2f(i*16, j*16), new Vector2f(16,16));
                        if (pacman_tile.Contains(p.Position.X, p.Position.Y)) {
                            target_tile = new Vector2f(pacman_tile.Left, pacman_tile.Top);
                            break;
                        }
                    }
                }
                switch (temp_name){
                    case "blinky":
                        break;
                    case "pinky":
                        switch (p.GetDirection()) {
                            case 0:
                                target_tile.X += 32;
                                break;
                            case 1:
                                target_tile.Y -= 32;
                                break;
                            case 2:
                                target_tile.X -= 32;
                                break;
                            case 3:
                                target_tile.Y += 32;
                                break;
                        }
                        break;
                    case "inky":
                        switch (p.GetDirection())
                        {
                            case 0:
                                target_tile.X += 16;
                                break;
                            case 1:
                                target_tile.Y -= 16;
                                break;
                            case 2:
                                target_tile.X -= 16;
                                break;
                            case 3:
                                target_tile.Y += 16;
                                break;
                        }

                        target_tile.X += target_tile.X - blinky.Position.X;
                        target_tile.Y += target_tile.Y - blinky.Position.Y;

                        break;
                    case "clyde":
                        if (Math.Sqrt(Math.Pow(Position.X - p.Position.X, 2) + Math.Pow(Position.Y - p.Position.Y, 2)) >= 64) {
                            break;
                        }
                        target_tile = new Vector2f(0, m.Size.Y + 32);
                        break;
                }
            }
        }

        public void SwitchAlpha(bool set) {
            for (int i = 0; i < vertices.Count - shrink_end; i++)
            {
                Vertex v = vertices[i];
                v.Color.A = (set) ? (byte)255 : (v.Color.A == 255) ? (byte)0 : (byte)255;
                vertices[i] = v;
            }
        }

        private float DistanceToTarget(byte d, float dtime) {
            Vector2f temp_pos = new Vector2f(0,0);

            switch (d)
            {
                case 0:
                    temp_pos = new Vector2f(Position.X + dtime * speed, Position.Y);
                    break;
                case 1:
                    temp_pos = new Vector2f(Position.X, Position.Y - dtime * speed);
                    break;
                case 2:
                    temp_pos = new Vector2f(Position.X - dtime * speed, Position.Y);
                    break;
                case 3:
                    temp_pos = new Vector2f(Position.X, Position.Y + dtime * speed);
                    break;
            }
            temp_pos = new Vector2f((float)Math.Round(temp_pos.X), (float)Math.Round(temp_pos.Y));

            return (float)Math.Sqrt(Math.Pow(temp_pos.X - target_tile.X, 2) + Math.Pow(temp_pos.Y - target_tile.Y, 2));
        }

        private bool CollidesWithPacman(Pacman p) {
            FloatRect this_rect = new FloatRect(new Vector2f(Position.X + (vertices[1].Position.X - vertices[0].Position.X)/4, Position.Y + (vertices[3].Position.Y - vertices[0].Position.Y)/4), new Vector2f((vertices[1].Position.X - vertices[0].Position.X)/2, (vertices[3].Position.Y - vertices[0].Position.Y)/2));
            FloatRect pacman_rect = new FloatRect(new Vector2f(p.Position.X + (p.GetVertices()[1].Position.X - p.GetVertices()[0].Position.X) / 4, p.Position.Y + (p.GetVertices()[3].Position.Y - p.GetVertices()[0].Position.Y) / 4), new Vector2f((p.GetVertices()[1].Position.X - p.GetVertices()[0].Position.X)/2, (p.GetVertices()[3].Position.Y - p.GetVertices()[0].Position.Y)/2));
            if (this_rect.Intersects(pacman_rect)) {
                return true;
            }
            return false;
        }

        private void SetEyesDir() {
            byte tdir = (mode_behavior != 1) ? dir : (byte)4;
            for (int i = 0; i < 4; i++)
            {
                Vertex v = vertices[4 + i];
                v.TexCoords = new Vector2f(eyes_tx[tdir][i * 2], eyes_tx[tdir][i * 2 + 1]);
                vertices[4 + i] = v;
            }
        }

        private void Flash(bool flash) { 
            for(int i = 0; i < vertices.Count - shrink_end; i++) {
                Vertex v = vertices[i];
                v.Color = (flash) ? new Color(255,255,255,255) : new Color(33,33,255,255);
                vertices[i] = v;
            }
        }

        public void Move(Map m, Pacman p, Ghost blinky, float dtime, uint level){
            bool canmove = false;
            byte available_ways = 0;
            bool[] collideswwall = new bool[4];
            //Console.Clear();
            for (int i = 0; i < 4; i++){
                collideswwall[i] = WillCollide(m, (byte)i, dtime);
                //Console.WriteLine(", COLLIDES: {0}", collideswwall[i]);
            }
            FloatRect entity_rect = new FloatRect(Position, entity_size);
            if (p.EnergizerTimer > 0.0f && mode_behavior == 0 && !immune_to_energizer) {
                mode_behavior = 1;
                InternalSetColor(new Color(33, 33, 255, 255));
            }
            if (p.EnergizerTimer == 0.0f){
                if (mode_behavior == 1){
                    InternalSetColor(entity_color);
                }
                mode_behavior = mode_behavior == 1 ? (byte)0 : mode_behavior;
                immune_to_energizer = immune_to_energizer ? !immune_to_energizer : immune_to_energizer;
                flashing_timer = 0.0f;
            }

            if((p.EnergizerTimer <= 0.3f && p.EnergizerTimer > 0.0f) && mode_behavior == 1) {
                flashing_timer += dtime;
                if(flashing_timer < 0.0009f) {
                    Flash(false);
                }
                else { 
                    if(flashing_timer >= 0.0018f) {
                        flashing_timer = 0;
                        Flash(true);
                    }
                }
            }

            float speed_factor = level / 256;
            speed_factor = speed_factor > 3.84f ? 3.84f : speed_factor;
            speed = (mode_behavior == 2) ? default_speed + (default_speed * 0.15f) : (mode_behavior == 1) ? default_speed - (default_speed * 0.10f) : default_speed;
            speed += speed * speed_factor; 

            UpdateTargets(p, m, blinky);

            if (mode_behavior != 1)
            {
                byte optimal_dir = 4;
                canmove = true;

                for (byte i = 0; i < 4; i++)
                {
                    if (i == (dir + 2) % 4)
                    {
                        continue;
                    }
                    if (!collideswwall[i])
                    {
                        if (optimal_dir == 4)
                        {
                            optimal_dir = i;
                        }

                        available_ways++;

                        if (DistanceToTarget(i, dtime) < DistanceToTarget(optimal_dir, dtime))
                        {
                            optimal_dir = i;
                        }
                    }
                }

                if (available_ways > 1)
                {
                    dir = optimal_dir;
                }
                else
                {
                    if (optimal_dir == 4)
                    {
                        dir = (byte)((dir + 2) % 4);
                    }
                    else
                    {
                        dir = optimal_dir;
                    }
                }
            }
            else {
                byte rand_dir = (byte)new Random().Next(0,4);

                canmove = true;
                for(byte i = 0; i < 4; i++){
                    if (i == (dir + 2) % 4)
                    {
                        continue;
                    }

                    if (!collideswwall[i])
                    {
                        available_ways++;
                    }
                }

                if(available_ways > 0) {
                    while (collideswwall[rand_dir] == true || rand_dir == (dir + 2) % 4)
                    {
                        rand_dir = (byte)new Random().Next(0,4);
                    }

                    dir = rand_dir;
                }
                else {
                    dir = (byte)((dir + 2) % 4);
                }
            }

            if (canmove){
                switch (dir)
                {
                    case 0:
                        Position = new Vector2f(Position.X + dtime * speed, Position.Y);
                        animation.PlayAnimation("move", dtime * 10);
                        break;
                    case 1:
                        Position = new Vector2f(Position.X, Position.Y - dtime * speed);
                        animation.PlayAnimation("move", dtime * 10);
                        break;
                    case 2:
                        Position = new Vector2f(Position.X - dtime * speed, Position.Y);
                        animation.PlayAnimation("move", dtime * 10);
                        break;
                    case 3:
                        Position = new Vector2f(Position.X, Position.Y + dtime * speed);
                        animation.PlayAnimation("move", dtime * 10);
                        break;
                }
                Position = new Vector2f((float)Math.Round(Position.X), (float)Math.Round(Position.Y));
                if (mode_behavior < 2)
                {
                    if (mode_movement)
                    {
                        soundPlayer.PlaySound("alert1");
                    }
                    else
                    {
                        soundPlayer.PlaySound("alert2");
                    }
                }
                else {
                    soundPlayer.PlaySound("run_away");
                }
            }
            if (Position.X >= m.Size.X-16)
            {
                Position = new Vector2f(Position.X - m.Size.X + 16, Position.Y);
            }
            if (Position.X <= 0)
            {
                Position = new Vector2f(Position.X + m.Size.X - 16, Position.Y);
            }
            if (Position.Y <= 0)
            {
                Position = new Vector2f(Position.X, Position.Y + m.Size.Y - 16);
            }
            if (Position.Y >= m.Size.Y-16)
            {
                Position = new Vector2f(Position.X, Position.Y - m.Size.Y + 16);
            }
            SetEyesDir();

            if (CollidesWithPacman(p)){
                if(mode_behavior == 0) {
                    p.Die(dtime);
                }
                if(mode_behavior == 1) {
                    mode_behavior = 2;
                    immune_to_energizer = true;
                    InternalSetColor(entity_color);
                    SwitchAlpha(false);
                    p.EatsGhost();
                    target_tile = new Vector2f(m.GetGhostHomeArea().Left + (m.GetGhostHomeArea().Width/2), m.GetGhostHomeArea().Top + (m.GetGhostHomeArea().Height / 2));
                }
            }
        }
    }
}
