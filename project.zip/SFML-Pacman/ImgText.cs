﻿using System.IO;
using System.Collections;
using System.Collections.Generic;
using SFML.Graphics;
using SFML.System;
using System;

namespace SFMLPacman
{
    public class ImgText : Transformable, Drawable
    {
        private List<Vertex> vertices = new List<Vertex>();
        private Dictionary<char, Vector2f[]> chardata = new Dictionary<char, Vector2f[]>();
        private Texture texture;
        private Color default_color = new Color(255,255,255,255);

        public ImgText(string texture_path) {
            texture = new Texture(texture_path);
        }
        public void LoadFontCfg(string p){
            Vector2f scanner_offset = new Vector2f(0,0);
            using (StreamReader _FIload = File.OpenText(p))
            {
                string rd_line;

                while ((rd_line = _FIload.ReadLine()) != null) {
                    string[] lineargs = rd_line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    for(int i = 0; i < lineargs.Length; i++) { 
                        if(lineargs[i] == "OFFSET") { 
                            scanner_offset = new Vector2f(float.Parse(lineargs[i+1]), float.Parse(lineargs[i + 2]));
                            break;
                        }
                        if(i == 0 && lineargs[i] != "OFFSET") {
                            chardata.Add(lineargs[i][0], new Vector2f[] { new Vector2f(scanner_offset.X, scanner_offset.Y), new Vector2f(float.Parse(lineargs[i + 1]), float.Parse(lineargs[i + 2])) });
                            scanner_offset.X += float.Parse(lineargs[i + 1]);
                        }
                    }
                }
                if (!chardata.ContainsKey(' '))
                {
                    chardata.Add(' ', new Vector2f[] { new Vector2f(162, 144), new Vector2f(5, 8) });
                    chardata.Add('\t', new Vector2f[] { new Vector2f(162, 144), new Vector2f(10, 8) });
                }
            }

        }

        public void SetText(string t)
        {
            vertices.Clear();
            Vector2f[] dat = new Vector2f[2];
            Vector2f padding = new Vector2f(0,0);
            bool endl = false;

            for (int i = 0; i < t.Length; i++){
                if (chardata.TryGetValue(t[i], out dat))
                {
                    padding.X = endl ? 0 : padding.X;

                    float new_y = endl ? vertices[vertices.Count - 1].Position.Y + 1 : padding.Y;

                    vertices.Add(new Vertex(new Vector2f(padding.X, new_y), default_color, new Vector2f(dat[0].X, dat[0].Y)));
                    vertices.Add(new Vertex(new Vector2f(dat[1].X + padding.X, new_y), default_color, new Vector2f(dat[0].X + dat[1].X, dat[0].Y)));
                    vertices.Add(new Vertex(new Vector2f(dat[1].X + padding.X, new_y+dat[1].Y), default_color, new Vector2f(dat[0].X + dat[1].X, dat[0].Y + dat[1].Y)));
                    vertices.Add(new Vertex(new Vector2f(padding.X, new_y+dat[1].Y), default_color, new Vector2f(dat[0].X, dat[0].Y + dat[1].Y)));

                    padding = new Vector2f(vertices[vertices.Count - 3].Position.X + 1, new_y);
                    endl = false;
                }

                if(t[i] == '\n' && vertices.Count >= 4) {
                    endl = true;
                }
            }
        }

        public void SetDefaultColor(Color color) {
            default_color = color;
        }

        public void SetColor(Color color)
        {
            for (int i = 0; i < vertices.Count; i++) {
                Vertex v = vertices[i];
                v.Color = color;
                vertices[i] = v;
            }
        }

        public void SetColor(Color color, int start, int end)
        {
            if (start*4 > vertices.Count || end*4 > vertices.Count || start*4 > end*4) {
                return;
            }
            for (int i = start*4; i < end*4; i++)
            {
                Vertex v = vertices[i];
                v.Color = color;
                vertices[i] = v;
            }
        }

        public void Clear() {
            vertices.Clear();
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            states.Transform *= Transform;
            states.Texture = texture;
            target.Draw(vertices.ToArray(), PrimitiveType.Quads, states);
        }

        public List<Vertex> GetVertices() {
            return vertices;
        }
    }
}
