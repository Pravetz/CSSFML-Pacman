﻿using System;
using System.Collections.Generic;
using System.IO;
using SFML.Graphics;
using SFML.System;
namespace SFMLPacman
{
    public class Map : Drawable
    {
        private List<Vertex> vertices = new List<Vertex>();
        private List<Vertex> wall_vertices = new List<Vertex>();
        private List<Vertex> edibles_vertices = new List<Vertex>();
        private Texture texture;
        private Dictionary<string, List<int[]>> tile_tx_data = new Dictionary<string, List<int[]>>();
        private List<int> power_pellet_ids = new List<int>();
        private List<int> fruit_id = new List<int>();
        private Vector2f[] home_area = { new Vector2f(-1, -1), new Vector2f(0, 0) };

        private Vector2f mapsize = new Vector2f(0, 0);
        private uint edible_count = 0;
        private uint edibles_eaten = 0;
        private float fruit_timer = 0.0f;
        private uint fruit_level = 0;
        public Vector2f Size
        {
            get {
                return mapsize;
            }
        }

        public Map(string p)
        {
            texture = new Texture(p);
        }


        public void LoadCfg(string p) {
            using (StreamReader _FIload = File.OpenText(p))
            {
                string rd_line;
                string read_to = "";

                while ((rd_line = _FIload.ReadLine()) != null)
                {
                    string[] lineargs = rd_line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    if (lineargs.Length == 8) {
                        int[] vrtxpos = new int[8];
                        for (int i = 0; i < lineargs.Length; i++) {
                            vrtxpos[i] = Convert.ToInt32(lineargs[i]);
                        }
                        tile_tx_data[read_to].Add(vrtxpos);
                    }
                    if (lineargs[0] == "CELLTYPE" && lineargs.Length == 2) {
                        read_to = lineargs[1];
                        if (!tile_tx_data.ContainsKey(read_to)) {
                            tile_tx_data.Add(read_to, new List<int[]>());
                        }
                    }
                }
            }
        }

        public void ResetMap() {
            edibles_eaten = 0;
            for (int i = 0; i < edibles_vertices.Count; i++)
            {
                Vertex v = edibles_vertices[i];
                v.Color.A = 255;
                edibles_vertices[i] = v;
                vertices[wall_vertices.Count + i] = v;
            }
            HideFruits();
        }

        public bool AreAllEdiblesEaten() {
            return edibles_eaten == edible_count;
        }

        private void HideFruits() {
            for (int i = 0; i < fruit_id.Count; i++)
            {
                for (int j = fruit_id[i]; j < fruit_id[i] + 4; j++)
                {
                    Vertex v = edibles_vertices[j];
                    v.Color.A = 0;
                    edibles_vertices[j] = v;
                    vertices[wall_vertices.Count + j] = v;
                }
            }
        }

        public void FruitDissapearTimer(float dtime) {
            fruit_timer -= dtime;
            if(fruit_timer <= 0.0f){
                HideFruits();
                fruit_timer = 0.0f;
            }
        }

        private void SpawnFruit(uint level) {
            int tile_id = fruit_id.Count >= 2 ? new Random().Next(0, fruit_id.Count) : 0;
            int fruit = level >= tile_tx_data["EDIBLE"].Count - 2 ? new Random().Next(2, tile_tx_data["EDIBLE"].Count) : (int) level + 2;
            fruit_level = (uint)fruit;
            
            if (edibles_eaten % 170 == 70 || edibles_eaten % 170 == 0) {
                int t = 0;
                for (int i = fruit_id[tile_id]; i < fruit_id[tile_id] + 4; i++) {
                    Vertex v = edibles_vertices[i];
                    v.TexCoords = new Vector2f(tile_tx_data["EDIBLE"][fruit][t], tile_tx_data["EDIBLE"][fruit][t+1]);
                    v.Color.A = 255;
                    edibles_vertices[i] = v;
                    vertices[wall_vertices.Count + i] = v;
                    t += 2;
                }
                fruit_timer = 0.15f;
            }
        }

        public uint EdibleEaten(int id, uint level) {
            for(int i = id; i < id + 4; i++) {
                Vertex v = edibles_vertices[i];
                v.Color = new Color(255,255,255,0);
                edibles_vertices[i] = v;
                vertices[wall_vertices.Count + i] = edibles_vertices[i];
            }
            if(power_pellet_ids.IndexOf(id) != -1) {
                edibles_eaten++;
                SpawnFruit(level);
                return 50;
            }
            if (fruit_id.IndexOf(id) != -1)
            {
                return 100 + (fruit_level - 2)*200;
            }

            edibles_eaten++;
            SpawnFruit(level);
            return 10;
        }

        private void GrowGhostHomeArea(Vector2f pos, Vector2f sz) { 
            if(home_area[0] == new Vector2f(-1, -1)) {
                home_area[0] = pos;
                home_area[1] += sz;
                return;
            }
            FloatRect home_rect = new FloatRect(home_area[0], home_area[1]);
            FloatRect tile_rect = new FloatRect(pos, sz);
            if (!home_rect.Intersects(tile_rect)) {
                if(pos.Y >= home_area[0].Y + home_area[1].Y) {
                    home_area[1].Y += sz.Y;
                }
                if(pos.X >= home_area[0].X + home_area[1].X) {
                    home_area[1].X += sz.X;
                }
            }
        }

        private void ClearMap() {
            vertices.Clear();
            wall_vertices.Clear();
            edibles_vertices.Clear();
            power_pellet_ids.Clear();
            fruit_id.Clear();
            mapsize = new Vector2f(0, 0);
            edible_count = 0;
            edibles_eaten = 0;
            fruit_timer = 0;
            home_area = new Vector2f[]{ new Vector2f(-1, -1), new Vector2f(0, 0) };
            fruit_level = 0;
        }

        public Dictionary<Color, Vector2f> Generate(string p, List<Color> entities_colors) {
            ClearMap();
            Dictionary<Color, Vector2f> ret_data = new Dictionary<Color, Vector2f>();
            Image mapimg = new Image(p);

            Color c = new Color(0,0,0,0);
            int coord_tx = 0;
            mapsize = new Vector2f(mapimg.Size.X * 16, mapimg.Size.Y * 16);
            for(uint i = 0; i < mapimg.Size.X; i++) { 
                for(uint j = 0; j < mapimg.Size.Y; j++) {
                    c = mapimg.GetPixel(i,j);
                    if (c == new Color(33, 33, 222, 255) || c == new Color(33, 33, 222, 254)) {
                        Color [] adj_c = new Color[4];
                        if(i >= 1) {
                            adj_c[0] = mapimg.GetPixel(i - 1, j);
                        }
                        if(j >= 1) {
                            adj_c[2] = mapimg.GetPixel(i, j - 1);
                        }
                        if(i + 1 < mapimg.Size.X){
                            adj_c[1] = mapimg.GetPixel(i + 1, j);
                        }
                        if(j + 1 < mapimg.Size.Y)
                        {
                            adj_c[3] = mapimg.GetPixel(i, j + 1);
                        }

                        //сусідні стіни...
                        //adj_c[0] - лівіше
                        //adj_c[1] - правіше 
                        //adj_c[2] - вище
                        //adj_c[3] - нижче поточної
                        string txbits = "";
                        for (uint k = 0; k < 4; k++)
                        {
                            if(adj_c[k].R == c.R && adj_c[k].G == c.G && adj_c[k].B == c.B){
                                txbits += "1";
                            }
                            else {
                                txbits += "0";
                            }
                        }
                        coord_tx = Convert.ToInt32(txbits, 2);

                        wall_vertices.Add(new Vertex(new Vector2f(i * 16, j * 16), c, new Vector2f(tile_tx_data["WALL"][coord_tx][0], tile_tx_data["WALL"][coord_tx][1])));
                        wall_vertices.Add(new Vertex(new Vector2f(i * 16 + 16, j * 16), c, new Vector2f(tile_tx_data["WALL"][coord_tx][2], tile_tx_data["WALL"][coord_tx][3])));
                        wall_vertices.Add(new Vertex(new Vector2f(i * 16 + 16, j * 16 + 16), c, new Vector2f(tile_tx_data["WALL"][coord_tx][4], tile_tx_data["WALL"][coord_tx][5])));
                        wall_vertices.Add(new Vertex(new Vector2f(i * 16, j * 16 + 16), c, new Vector2f(tile_tx_data["WALL"][coord_tx][6], tile_tx_data["WALL"][coord_tx][7])));
                        if(c.A == 254) {
                            GrowGhostHomeArea(new Vector2f(i*16, j*16), new Vector2f(16,16));
                        }
                        continue;
                    }
                    if(c.R == 255 && c.G == 255 && c.B == 255) {
                        if (c.A <= 1)
                        {
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16, j * 16), new Color(255, 255, 255, 255), new Vector2f(tile_tx_data["EDIBLE"][c.A][0], tile_tx_data["EDIBLE"][c.A][1])));
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16 + 16, j * 16), new Color(255, 255, 255, 255), new Vector2f(tile_tx_data["EDIBLE"][c.A][2], tile_tx_data["EDIBLE"][c.A][3])));
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16 + 16, j * 16 + 16), new Color(255, 255, 255, 255), new Vector2f(tile_tx_data["EDIBLE"][c.A][4], tile_tx_data["EDIBLE"][c.A][5])));
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16, j * 16 + 16), new Color(255, 255, 255, 255), new Vector2f(tile_tx_data["EDIBLE"][c.A][6], tile_tx_data["EDIBLE"][c.A][7])));
                        }
                        else {
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16, j * 16), new Color(255, 255, 255, 0)));
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16 + 16, j * 16), new Color(255, 255, 255, 0)));
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16 + 16, j * 16 + 16), new Color(255, 255, 255, 0)));
                            edibles_vertices.Add(new Vertex(new Vector2f(i * 16, j * 16 + 16), new Color(255, 255, 255, 0)));
                        }
                        edible_count++;
                        if (c.A == 1) {
                            power_pellet_ids.Add(edibles_vertices.Count-4);
                        }
                        if (c.A == 2)
                        {
                            fruit_id.Add(edibles_vertices.Count - 4);
                            edible_count--;
                        }
                        continue;
                    }
                    if(c.R == 159 && c.G == 133 && c.B == 115 && c.A <= tile_tx_data["DOOR"].Count) {
                        wall_vertices.Add(new Vertex(new Vector2f((i * 16) - 4, j * 16), new Color(c.R,c.G,c.B,255), new Vector2f(tile_tx_data["DOOR"][c.A][0], tile_tx_data["DOOR"][c.A][1])));
                        wall_vertices.Add(new Vertex(new Vector2f(i * 16 + 20, j * 16), new Color(c.R, c.G, c.B, 255), new Vector2f(tile_tx_data["DOOR"][c.A][2], tile_tx_data["DOOR"][c.A][3])));
                        wall_vertices.Add(new Vertex(new Vector2f(i * 16 + 20, j * 16 + 16), new Color(c.R, c.G, c.B, 255), new Vector2f(tile_tx_data["DOOR"][c.A][4], tile_tx_data["DOOR"][c.A][5])));
                        wall_vertices.Add(new Vertex(new Vector2f((i * 16) - 4, j * 16 + 16), new Color(c.R, c.G, c.B, 255), new Vector2f(tile_tx_data["DOOR"][c.A][6], tile_tx_data["DOOR"][c.A][7])));
                        continue;
                    }
                    if(entities_colors.IndexOf(c) != -1) {
                        ret_data.Add(c, new Vector2f(16*i, 16*j));
                    }
                }
            }
            vertices.AddRange(wall_vertices);
            vertices.AddRange(edibles_vertices);

            return ret_data;
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            states.Texture = texture;
            target.Draw(vertices.ToArray(), PrimitiveType.Quads, states);
        }

        public List<Vertex> GetVertices()
        {
            return vertices;
        }

        public List<Vertex> GetWallsVertices(){
            return wall_vertices;
        }

        public List<Vertex> GetEdiblesVertices()
        {
            return edibles_vertices;
        }

        public List<Vector2f> GetDoorsPos() {
            List<Vector2f> dpos = new List<Vector2f>();
            for(int i = 0; i < vertices.Count; i += 4) {
                if(vertices[i].Color == new Color(159, 133, 115, 255)) {
                    dpos.Add(new Vector2f(vertices[i].Position.X + 4, vertices[i].Position.Y));
                }
            }
            return dpos;
        }

        public FloatRect GetGhostHomeArea() {
            return new FloatRect(new Vector2f(home_area[0].X + 12, home_area[0].Y + 12), new Vector2f(home_area[1].X/2, home_area[1].Y/2)); 
        }
    }
}
