﻿using System;
using SFML.Graphics;
using SFML.System;
using System.Collections.Generic;

namespace SFMLPacman
{
    public sealed class PacLifes : Transformable, Drawable
    {
        private List<Vertex> vertices = new List<Vertex>();
        private Texture texture;
        private Color color = new Color();
        private int[] texture_coords = new int[8];

        private Vector2f Size = new Vector2f(0,0);

        public PacLifes(string tx_path, int [] txc, Color c, Vector2f size)
        {
            texture = new Texture(tx_path);
            Array.Copy(txc, texture_coords, txc.Length);
            color = c;
            Size = size;
        }

        public void SetLifes(int lifecount) {
            vertices.Clear();

            for(int i = 0; i < lifecount; i++) {
                vertices.Add(new Vertex(new Vector2f(Position.X + Size.X * i, Position.Y), color, new Vector2f(texture_coords[0], texture_coords[1])));
                vertices.Add(new Vertex(new Vector2f(Position.X + Size.X * i + Size.X, Position.Y), color, new Vector2f(texture_coords[2], texture_coords[3])));
                vertices.Add(new Vertex(new Vector2f(Position.X + Size.X * i + Size.X, Position.Y + Size.Y), color, new Vector2f(texture_coords[4], texture_coords[5])));
                vertices.Add(new Vertex(new Vector2f(Position.X + Size.X * i, Position.Y + Size.Y), color, new Vector2f(texture_coords[6], texture_coords[7])));
            }
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            states.Texture = texture;
            states.Transform *= Transform;
            target.Draw(vertices.ToArray(), PrimitiveType.Quads, states);
        }
    }
}
