﻿using System;
using System.IO;
namespace SFMLPacman
{
    public sealed class PacLog
    {
        private string fs_log_path;
        private string log_name = "";

        public PacLog(string lpath)
        {
            fs_log_path = lpath;
        }

        public void WriteLog(Exception e){
            if(log_name.Length == 0) {
                log_name = "Pacman_" + DateTime.Now + ".log";
            }
            using (StreamWriter log_write = File.AppendText(fs_log_path + log_name)) {
                log_write.WriteLine(e);
            }
        }
    }
}
