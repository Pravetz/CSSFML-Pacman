﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using SFML.Graphics;
using SFML.System;

namespace SFMLPacman
{
    [TestFixture]
    public class PacmanTests
    {
        Map test_m = new Map("assets/gfx/game_atlas.png");
        Pacman test_pac;
        List<Color> e_colors = new List<Color>();
        static Dictionary<Color, Vector2f> test_entity_pos_data;

        [OneTimeSetUp]
        public void SetupTest() {
            test_m.LoadCfg("assets/configs/maptiles/maptx.txt");
            e_colors.Add(new Color(255, 0, 0, 255));
            e_colors.Add(new Color(255, 184, 255, 255));
            e_colors.Add(new Color(0, 255, 255, 255));
            e_colors.Add(new Color(255, 184, 81, 255));
            e_colors.Add(new Color(255, 255, 0, 255));
            test_pac = new Pacman(new Vector2f(16, 16), e_colors[4], new int[]{ 0,0,16,0,16,16,0,16 }, "100");
        }


        [Test]
        public void MapGenTest()
        {
            test_entity_pos_data = test_m.Generate("assets/gfx/maps/classic_map.png", e_colors);
            int counter_true = 0;
            for (int i = 0; i < test_entity_pos_data.Count; i++)
            {
                if(test_entity_pos_data.ContainsKey(e_colors[i])){
                    counter_true++;
                }
            }

            Assert.IsTrue(counter_true == e_colors.Count);
            test_pac.Position = test_entity_pos_data[e_colors[4]];
        }

        [Test]
        public void PacmanEatScoreTest() {
            uint score = test_pac.Score;
            test_pac.Move(0.0015f, test_m, 0);

            Assert.IsTrue(score < test_pac.Score);
        }

        [Test]
        public void PacmanWallCollisionTest() {
            test_pac.SetDirection(1);
            test_pac.Move(0.0015f, test_m, 0);
            Assert.IsFalse(test_pac.Collides(test_m));
        }
    }
}
