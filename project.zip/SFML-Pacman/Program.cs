﻿using System;
using SFML.System;
using SFML.Graphics;
using SFML.Audio;
using SFML.Window;
using System.IO;
using System.Collections.Generic;

namespace SFMLPacman
{
    class Game
    {
        static VideoMode vmode;
        static PacLog logger;
        static PacLifes lifebar;
        static Dictionary<string, string> GAME_PATHS = new Dictionary<string,string>();
        static List<string> GAME_TEXT = new List<string>();
        static Keyboard.Key[] mvkeys = { Keyboard.Key.D, Keyboard.Key.W, Keyboard.Key.A, Keyboard.Key.S };
        static Pacman p;
        static List<Ghost> ghosts = new List<Ghost>();
        static List<Color> entities_colors = new List<Color>();
        static View game_view;
        static Map m;
        static Batcher b;
        static Dictionary<Color, Vector2f> entity_pos_data;
        static List<ImgText> gametext = new List<ImgText>();

        static bool fullscreen = false;
        static bool is_in_menu = true;
        static bool lost = false;
        static bool paused = false;
        static bool setup_failed = false;
        static float UI_blink_timer = 0.0f;

        static List<float[]> overlay_data = new List<float[]>();

        static void LoadGameText(string path) {
            using (StreamReader _FIload = File.OpenText(path))
            {
                string rd_line;

                while ((rd_line = _FIload.ReadLine()) != null)
                {
                    GAME_TEXT.Add(rd_line);
                }
            }
        }

        static void LoadSettings(string settings_path) {
            if (!File.Exists(settings_path))
            {
                using (StreamWriter create_settings = File.AppendText(settings_path))
                {
                    create_settings.WriteLine("FULLSCREEN=True\nWINDOW_WIDTH=1368\nWINDOW_HEIGHT=768\nGAME_TX_PATH=assets/gfx/game_atlas.png\nGHOSTS_DEF_PATH=assets/configs/entities/ghosts.txt\nPACMAN_DEF_PATH=assets/configs/entities/pacman.txt\nGHOST_EYES_TXDEF=assets/configs/entities/ghost_eyes_textures.txt\nMAP_TILE_TXDEF_PATH=assets/configs/maptiles/maptx.txt\nMAPS_PATH=assets/gfx/maps/\nDEFAULT_MAP=classic_map.png\nDEFAULT_LANG=EN\nCHARS_PATH=assets/configs/font/\nTEXT_PATH=assets/text/\nLOG_PATH=logs/\nUI_OVERLAY_PATH=assets/configs/UI/ui_overlay.txt\nPACMAN_LIFES_BAR_DEF=assets/configs/UI/paclifes.txt\nSOUND_VOLUME=100\nRANDOM_MAPS=False".Replace('/', Path.DirectorySeparatorChar));
                }
                LoadSettings(settings_path);
            }
            else
            {
                using (StreamReader _FIload = File.OpenText(settings_path))
                {
                    string rd_line;

                    while ((rd_line = _FIload.ReadLine()) != null)
                    {
                        string[] lineargs = rd_line.Split(new char[] { '=', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                        GAME_PATHS.Add(lineargs[0], lineargs[1]);
                    }
                }
            }
        }

        static void LoadLifeBar(string cfgpath) {
            using (StreamReader _FIload = File.OpenText(cfgpath))
            {
                char[] special_tokens = { 'r', 'g', 'b', 'a', 'x', 'y' };
                string rd_line;

                while ((rd_line = _FIload.ReadLine()) != null)
                {
                    string[] lineargs = rd_line.Split(new char[] { ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);

                    if (lineargs.Length == 14)
                    {
                        Color temp_color = new Color(0, 0, 0, 0);
                        Vector2f temp_size = new Vector2f(0, 0);
                        List<int> temp_tx_coords = new List<int>();
                        for (int i = 0; i < lineargs.Length; i++)
                        {
                            if (lineargs[i][0] == 'r')
                            {
                                temp_color.R = Convert.ToByte(lineargs[i].Replace("r", ""));
                                continue;
                            }
                            if (lineargs[i][0] == 'g')
                            {
                                temp_color.G = Convert.ToByte(lineargs[i].Replace("g", ""));
                                continue;
                            }
                            if (lineargs[i][0] == 'b')
                            {
                                temp_color.B = Convert.ToByte(lineargs[i].Replace("b", ""));
                                continue;
                            }
                            if (lineargs[i][0] == 'a')
                            {
                                temp_color.A = Convert.ToByte(lineargs[i].Replace("a", ""));
                                continue;
                            }
                            if (Array.IndexOf(special_tokens, lineargs[i][0]) == -1)
                            {
                                temp_tx_coords.Add(Convert.ToInt32(lineargs[i]));
                                continue;
                            }
                            if (lineargs[i][0] == 'x')
                            {
                                temp_size.X = Convert.ToSingle(lineargs[i].Replace("x", ""));
                                continue;
                            }
                            if (lineargs[i][0] == 'y')
                            {
                                temp_size.Y = Convert.ToSingle(lineargs[i].Replace("y", ""));
                                continue;
                            }
                        }
                        lifebar = new PacLifes(GAME_PATHS["GAME_TX_PATH"], temp_tx_coords.ToArray(), temp_color, temp_size);
                    }
                }
            }

        }

        static int LoadEntity(string cfgpath, string entity_type)
        {
            int id = -1;
            using (StreamReader _FIload = File.OpenText(cfgpath))
            {
                char[] special_tokens = { 'r', 'g', 'b', 'a', 'x', 'y', '\"' };
                string rd_line;

                while ((rd_line = _FIload.ReadLine()) != null)
                {
                    string[] lineargs = rd_line.Split(new char[] { ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);

                    if ((entity_type == "ghost" && lineargs.Length >= 15) || (entity_type == "pacman" && lineargs.Length >= 14)) {
                        Color temp_color = new Color(0,0,0,0);
                        Vector2f temp_size = new Vector2f(0,0);
                        List<int> temp_tx_coords = new List<int>();
                        int namearg_id = -1;
                        for(int i = 0; i < lineargs.Length; i++) {
                            if(lineargs[i][0] == 'r') {
                                temp_color.R = Convert.ToByte(lineargs[i].Replace("r", ""));
                                continue;
                            }
                            if (lineargs[i][0] == 'g')
                            {
                                temp_color.G = Convert.ToByte(lineargs[i].Replace("g", ""));
                                continue;
                            }
                            if (lineargs[i][0] == 'b')
                            {
                                temp_color.B = Convert.ToByte(lineargs[i].Replace("b", ""));
                                continue;
                            }
                            if (lineargs[i][0] == 'a')
                            {
                                temp_color.A = Convert.ToByte(lineargs[i].Replace("a", ""));
                                continue;
                            }
                            if (Array.IndexOf(special_tokens, lineargs[i][0]) == -1) {
                                temp_tx_coords.Add(Convert.ToInt32(lineargs[i]));
                                continue;
                            }
                            if(lineargs[i][0] == 'x') {
                                temp_size.X = Convert.ToSingle(lineargs[i].Replace("x",""));
                                continue;
                            }
                            if(lineargs[i][0] == 'y')
                            {
                                temp_size.Y = Convert.ToSingle(lineargs[i].Replace("y", ""));
                                continue;
                            }
                            if(lineargs[i][0] == '\"') {
                                namearg_id = i;
                                continue;
                            }
                        }
                        if (entity_type == "ghost")
                        {
                            ghosts.Add(new Ghost(temp_size, temp_color, temp_tx_coords.ToArray(), lineargs[namearg_id].Replace("\"", ""), GAME_PATHS["GHOST_EYES_TXDEF"], GAME_PATHS["SOUND_VOLUME"]));
                            if(lineargs[namearg_id].Replace("\"", "").ToLower() == "blinky") {
                                id = ghosts.Count - 1;
                            }
                        }
                        else {
                            p = new Pacman(temp_size, temp_color, temp_tx_coords.ToArray(), GAME_PATHS["SOUND_VOLUME"]);
                        }
                        entities_colors.Add(temp_color);
                    }
                }
            }

            return id;
        }
        public static void SetEntitiesPositions() {
            for (int i = 0; i < ghosts.Count; i++)
            {
                ghosts[i].Position = entity_pos_data[ghosts[i].GetVertices()[0].Color];
            }
            p.Position = entity_pos_data[p.GetVertices()[0].Color];
        }

        public static void LoadOverlay(string path) {
            using (StreamReader _FIload = File.OpenText(path))
            {
                string rd_line;

                while ((rd_line = _FIload.ReadLine()) != null)
                {
                    string[] lineargs = rd_line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                    float[] uiargs = new float[lineargs.Length];

                    for (int i = 0; i < lineargs.Length; i++) {
                        uiargs[i] = Convert.ToSingle(lineargs[i]);
                    }

                    overlay_data.Add(uiargs);
                }
            }
        }

        public static void SetOverlay() { 
            for(int i = 0; i < overlay_data.Count; i++) { 
                if(overlay_data[i].Length >= 4) {
                    gametext[i].Position = new Vector2f(vmode.Width * overlay_data[i][0], vmode.Height * overlay_data[i][1]);
                    gametext[i].Scale = new Vector2f(overlay_data[i][2], overlay_data[i][3]);
                }
                if(overlay_data[i].Length == 8) {
                    gametext[i].SetColor(new Color((byte)overlay_data[i][4], (byte)overlay_data[i][5], (byte)overlay_data[i][6], (byte)overlay_data[i][7]));
                }
            }
        }

        public static void GenerateMap(string path) {
            entity_pos_data = m.Generate(path, entities_colors);
            SetEntitiesPositions();
        }

        public static void UpdateBatch() {
            b.Clear();
            b.Add(m);
            b.Add(p);
            for(int i = 0; i < ghosts.Count; i++) {
                b.Add(ghosts[i]);
            }
            b.Add(gametext[9]);
        }

        public static void Main(string[] args)
        {
            int blinky_id = 0;
            float chase_timer = 0.0f;
            uint level = 0;
            uint wave = 0;
            bool chase_in_progress = false;
            bool start = true;
            LoadSettings("assets/settings.txt");
            Batcher UIbatch = new Batcher(GAME_PATHS["GAME_TX_PATH"]);
            fullscreen = Convert.ToBoolean(GAME_PATHS["FULLSCREEN"]);
            vmode = new VideoMode(Convert.ToUInt16(GAME_PATHS["WINDOW_WIDTH"]), Convert.ToUInt16(GAME_PATHS["WINDOW_HEIGHT"]));
            
            logger = new PacLog(GAME_PATHS["LOG_PATH"]);
            try
            {
                LoadOverlay(GAME_PATHS["UI_OVERLAY_PATH"]);
                LoadGameText(GAME_PATHS["TEXT_PATH"] + GAME_PATHS["DEFAULT_LANG"] + ".txt");
                blinky_id = LoadEntity(GAME_PATHS["GHOSTS_DEF_PATH"], "ghost");
                LoadEntity(GAME_PATHS["PACMAN_DEF_PATH"], "pacman");
                LoadLifeBar(GAME_PATHS["PACMAN_LIFES_BAR_DEF"]);
                m = new Map(GAME_PATHS["GAME_TX_PATH"]);
                b = new Batcher(GAME_PATHS["GAME_TX_PATH"]);

                for (int i = 0; i < GAME_TEXT.Count; i++) {
                    string[] charfiles = Directory.GetFiles(GAME_PATHS["CHARS_PATH"]);
                    ImgText newtext = new ImgText(GAME_PATHS["GAME_TX_PATH"]);
                    for (int j = 0; j < charfiles.Length; j++) {
                        newtext.LoadFontCfg(charfiles[j]);
                    }
                    newtext.SetText(GAME_TEXT[i]);
                    gametext.Add(newtext);
                }
                SetOverlay();

                m.LoadCfg(GAME_PATHS["MAP_TILE_TXDEF_PATH"]);
                GenerateMap(GAME_PATHS["MAPS_PATH"] + GAME_PATHS["DEFAULT_MAP"]);
                SetEntitiesPositions();
                lifebar.Position = new Vector2f(0, m.Size.Y/2);
            }
            catch (Exception e)
            {
                logger.WriteLog(e);
                setup_failed = true;
            }

            if (setup_failed) {
                return;
            }

            game_view = new View(new Vector2f(m.Size.X / 2, m.Size.Y / 2), new Vector2f(vmode.Width, vmode.Height));
            RenderWindow game = new RenderWindow(vmode, "Pacman");
            if (fullscreen){
                vmode = VideoMode.DesktopMode;
                game = new RenderWindow(vmode, "Pacman", Styles.Fullscreen);
            }
            game.Closed += Game_Closed;
            game.KeyPressed += Game_KeyPressed;
            game.Resized += Game_Resized;

            game.SetFramerateLimit(60);

            UIbatch.Add(p);
            for (int i = 0; i < ghosts.Count; i++) {
                UIbatch.Add(ghosts[i]);
            }

            UpdateBatch();
            Clock clock = new Clock();
            while (game.IsOpen) {
                clock.Restart();
                game.DispatchEvents();
                game.SetView(game_view);

                game.Clear(new Color(0,0,0,255));
                if (!is_in_menu)
                {
                    game_view.Center = new Vector2f(m.Size.X / 2, m.Size.Y / 2);
                    if (!lost)
                    {
                        if (!paused)
                        {
                            if(!start)
                            {
                                if (m.AreAllEdiblesEaten())
                                {
                                    if (UI_blink_timer >= -0.0015f)
                                    {
                                        UI_blink_timer -= clock.ElapsedTime.AsSeconds();
                                    }
                                    else
                                    {
                                        level++;
                                        wave = 0;
                                        chase_in_progress = false;
                                        chase_timer = 0.0f;
                                        UI_blink_timer = 0.0f;
                                        for (int i = 0; i < ghosts.Count; i++)
                                        {
                                            ghosts[i].SwitchAlpha(true);
                                            ghosts[i].Reset();
                                            ghosts[i].ResetMode();
                                        }
                                        bool randomize = Convert.ToBoolean(GAME_PATHS["RANDOM_MAPS"]);
                                        if (randomize) {
                                            string[] maps = Directory.GetFiles(GAME_PATHS["MAPS_PATH"]);

                                            GenerateMap(maps[new Random().Next(0, maps.Length)]);
                                            UpdateBatch();
                                            lifebar.Position = new Vector2f(0, m.Size.Y / 2);
                                        }
                                        SetEntitiesPositions();
                                        p.ResetEnergizer();
                                        m.ResetMap();
                                        start = true;
                                    }
                                }
                                if (!p.IsDying && p.Lifes >= 0)
                                {
                                    chase_timer += 0.01f;
                                    if (chase_timer >= 7.0f + ((wave * 10) * Convert.ToUInt32(chase_in_progress)) - (wave / (10 * (level + 1))) - 0.5f * (Convert.ToUInt32(!chase_in_progress) * level))
                                    {
                                        for (int i = 0; i < ghosts.Count; i++)
                                        {
                                            ghosts[i].SwitchMode();
                                        }
                                        wave++;
                                        chase_in_progress = !chase_in_progress;
                                        chase_timer = 0.0f;
                                    }
                                    m.FruitDissapearTimer(0.00015f);
                                    p.EnergizerClock(0.00015f);
                                    p.Move(0.00015f, m, level);

                                    for(int i = 0; i < ghosts.Count; i++)
                                    {
                                        ghosts[i].Move(m, p, ghosts[blinky_id], 0.00015f, level);
                                    }
                                    lifebar.SetLifes(p.Lifes);
                                }
                                else
                                {
                                    for (int i = 0; i < ghosts.Count; i++)
                                    {
                                        ghosts[i].SwitchAlpha(true);
                                        ghosts[i].Reset();
                                    }
                                    if (p.Die(0.00015f) && p.Lifes >= 0)
                                    {
                                        SetEntitiesPositions();
                                    }
                                    if (p.Lifes == -2)
                                    {
                                        lost = true;
                                    }
                                }
                            }
                            else {
                                UI_blink_timer += clock.ElapsedTime.AsSeconds();
                                if(UI_blink_timer >= 0.05f) {
                                    start = false;
                                    UI_blink_timer = 0.0f;
                                }
                            }
                        }
                        gametext[9].SetText(GAME_TEXT[9] + p.Score.ToString());
                        game.Draw(b);
                        game.Draw(lifebar);
                        if (paused){
                            game.Draw(gametext[13]);
                        }
                        if (start){
                            game.Draw(gametext[8]);
                        }
                    }
                    else
                    {
                        level = 0;
                        wave = 0;
                        chase_timer = 0;
                        chase_in_progress = false;
                        start = true;
                        game_view.Center = new Vector2f(vmode.Width / 2, vmode.Height / 2);
                        if (UI_blink_timer < 0.008f)
                        {
                            for (int i = 10; i < 13; i++) {
                                game.Draw(gametext[i]);
                            }
                            UI_blink_timer += clock.ElapsedTime.AsSeconds();
                        }
                        else
                        {
                            UI_blink_timer += clock.ElapsedTime.AsSeconds();
                            if (UI_blink_timer >= 0.01f)
                            {
                                UI_blink_timer = 0;
                            }
                        }
                    }
                }

                else {
                    game.Draw(gametext[0]);

                    p.Position = new Vector2f(gametext[7].Position.X - p.EntitySize.X - 2, gametext[7].Position.Y);
                    int[] ghost_counters = { 0,0,0,0 };
                    for(int i = 0; i < ghosts.Count; i++){ 
                        if(ghosts[i].Name.ToLower() == "blinky") {
                            ghosts[i].Position = new Vector2f(gametext[3].Position.X - (ghost_counters[0] + 1)*(ghosts[i].EntitySize.X + 2), gametext[3].Position.Y);
                            ghost_counters[0]++;
                        }
                        if (ghosts[i].Name.ToLower() == "pinky")
                        {
                            ghosts[i].Position = new Vector2f(gametext[4].Position.X - (ghost_counters[1] + 1) * (ghosts[i].EntitySize.X + 2), gametext[4].Position.Y);
                            ghost_counters[1]++;
                        }
                        if (ghosts[i].Name.ToLower() == "inky")
                        {
                            ghosts[i].Position = new Vector2f(gametext[5].Position.X - (ghost_counters[2] + 1) * (ghosts[i].EntitySize.X + 2), gametext[5].Position.Y);
                            ghost_counters[2]++;
                        }
                        if (ghosts[i].Name.ToLower() == "clyde")
                        {
                            ghosts[i].Position = new Vector2f(gametext[6].Position.X - (ghost_counters[3] + 1) * (ghosts[i].EntitySize.X + 2), gametext[6].Position.Y);
                            ghost_counters[3]++;
                        }
                    }

                    for (int i = 3; i < 8; i++)
                    {
                        game.Draw(gametext[i]);
                    }

                    if (UI_blink_timer < 0.008f)
                    {
                        for (int i = 1; i < 3; i++)
                        {
                            game.Draw(gametext[i]);
                        }
                        UI_blink_timer += clock.ElapsedTime.AsSeconds();
                    }
                    else
                    {
                        UI_blink_timer += clock.ElapsedTime.AsSeconds();
                        if (UI_blink_timer >= 0.01f)
                        {
                            UI_blink_timer = 0;
                        }
                    }
                    game.Draw(UIbatch);
                }

                game.Display();
            }
        }

        static void Game_KeyPressed(object sender, KeyEventArgs e)
        {
            RenderWindow gw = sender as RenderWindow;

            if (e.Code == Keyboard.Key.Escape && (is_in_menu || lost || paused)) {
                gw.Close();
            }
            if (e.Code == Keyboard.Key.P && (!is_in_menu && !lost))
            {
                paused = !paused;
            }
            if (e.Code == Keyboard.Key.Enter && is_in_menu && !lost)
            {
                SetEntitiesPositions();
                is_in_menu = false;
                UI_blink_timer = 0.0f;
            }
            if (e.Code == Keyboard.Key.Enter && lost)
            {
                p.Restart();
                SetEntitiesPositions();
                m.ResetMap();
                for(int i = 0; i < ghosts.Count; i++) {
                    ghosts[i].Reset();
                    ghosts[i].ResetMode();
                }
                lost = false;
                UI_blink_timer = 0.0f;
            }
            if (Array.IndexOf(mvkeys, e.Code) != -1 && !paused && !is_in_menu && !lost){
                p.SetDirection((byte)Array.IndexOf(mvkeys, e.Code));
            }
        }


        static void Game_Closed(object sender, EventArgs e)
        {
            RenderWindow gw = sender as RenderWindow;
            gw.Close();
        }

        static void Game_Resized(object sender, SizeEventArgs e)
        {
            RenderWindow w = sender as RenderWindow;
            game_view.Size = new Vector2f(e.Width, e.Height);
            game_view.Center = new Vector2f(m.Size.X/2, m.Size.Y/2);
            vmode.Width = e.Width;
            vmode.Height = e.Height;
            game_view.Zoom((m.Size.X * 100 / vmode.Width + m.Size.Y * 100 / vmode.Height) / 100);
            SetOverlay();
        }
    }
}
