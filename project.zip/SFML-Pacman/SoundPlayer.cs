﻿using System.IO;
using System.Collections.Generic;
using SFML.Audio;
using System;
using System.Linq;

namespace SFMLPacman
{
    public class SoundPlayer
    {
        private Dictionary<string, SoundBuffer> sounds = new Dictionary<string, SoundBuffer>();
        private static Dictionary<string, Sound> players = new Dictionary<string, Sound>();
        private float volume = 1.0f;

        public SoundPlayer() { }

        public void LoadSounds(string path) {
            using (StreamReader _FIload = File.OpenText(path))
            {
                string rd_line;

                while ((rd_line = _FIload.ReadLine()) != null)
                {
                    string[] lineargs = rd_line.Split(new char[] { '=', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    if (lineargs[0][0] == '\"' && lineargs.Length == 2)
                    {
                        sounds.Add(lineargs[0].Replace("\"", ""), new SoundBuffer(lineargs[1]));
                        if (!players.ContainsKey(lineargs[0].Replace("\"", "")))
                        {
                            players.Add(lineargs[0].Replace("\"", ""), new Sound(sounds[lineargs[0].Replace("\"", "")]));
                        }
                    }
                }
            }
        }

        public void PlaySound(string name) {
            if (sounds.ContainsKey(name)){
                if (players[name].Status != SoundStatus.Playing)
                {
                    players[name].SoundBuffer = sounds[name];
                    players[name].Volume = volume;
                    players[name].Play();
                }
            }
        }

        public void SetVolume(float vol) {
            volume = vol;
        }

        public float GetVolume()
        {
            return volume;
        }

        public void StopSounds() {
            for (int i = 0; i < players.Count; i++)
            {
                players.ElementAt(i).Value.Stop();
            }
        }
    }
}
